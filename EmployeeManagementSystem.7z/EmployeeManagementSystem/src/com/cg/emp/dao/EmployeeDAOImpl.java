package com.cg.emp.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.util.CollectionUtil;

public  class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public int addEmployee(Integer id,Employee ee) throws EmployeeException {
	         //logic in which employee object is getting stored
		CollectionUtil.addEmployee(id,ee);
		return ee.getEmpid();
	}
	

	@Override
	public Employee getEmpById(int empid) {
		Employee e=CollectionUtil.getEmpById(empid);
		return e;
	}

	@Override
	public ArrayList<Employee> sortEmpByName() {
		ArrayList<Employee> al=CollectionUtil.sortEmpByName();
		return al;
		
	}

	@Override
	public  HashMap<Integer, Employee> deleteEmp(int empid) {
		HashMap<Integer, Employee> i=CollectionUtil.deleteEmp(empid);
		return i;
	}

	@Override
	public Employee updateEmp(int empid, String newName, float newSal) {
		Employee e=CollectionUtil.UpdateEmp(empid, newName, newSal);
		return e;
	}
	@Override
	public HashMap<Integer,Employee> fetchAllEmp()  {
		HashMap h=CollectionUtil.fetchAllEmp();
		return h;
	}



}
