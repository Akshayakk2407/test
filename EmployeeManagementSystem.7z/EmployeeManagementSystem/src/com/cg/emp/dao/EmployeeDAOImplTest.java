package com.cg.emp.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.Month;

import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;

class EmployeeDAOImplTest {
	//static EmployeeDAOImpl empdao=null; 
	//@BeforeClass
		//public static void setUp()
		//{
	static EmployeeDAOImpl empdao=new EmployeeDAOImpl();
		//} 
	@Test
	void test1() throws EmployeeException {
		assertEquals(1111, empdao.addEmployee(1111,
				new Employee(1111,"aaa",40000.0F,
						LocalDate.now())));
	}
	@Test
	void test2() throws  EmployeeException{
		Employee e=new Employee(1001,"uday",45000.0F,LocalDate.of(2019,Month.JANUARY,04));
		
		assertEquals(e,empdao.getEmpById(1001));
	}

}
