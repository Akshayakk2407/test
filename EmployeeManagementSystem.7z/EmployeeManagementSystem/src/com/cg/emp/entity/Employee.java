package com.cg.emp.entity;

import java.time.LocalDate;
import java.util.Comparator;

public class Employee {
	private int empid;
	private String empname;
	private float empsal;
	private  LocalDate empDOJ;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Employee(int empid, String empname, float empsal, LocalDate empDOJ) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.empsal = empsal;
		this.empDOJ = empDOJ;
	}

	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public float getEmpsal() {
		return empsal;
	}
	public void setEmpsal(float empsal) {
		this.empsal = empsal;
	}
	public LocalDate getEmpDOJ() {
		return empDOJ;
	}
	public void setEmpDOJ(LocalDate empDOJ) {
		this.empDOJ = empDOJ;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", empsal=" + empsal + ", empDOJ=" + empDOJ + "]";
	}
	public static Comparator<Employee> getCompByName()
	{
		Comparator<Employee> comp=new Comparator<Employee>() {

			@Override
			public int compare(Employee a, Employee b) {
				
				return a.empname.compareTo(b.empname);
			}
			
		};
		return comp;
	}
	
}

