package com.cg.emp.exception;

public class EmployeeException extends Exception{

	public EmployeeException(String s)
	{
		System.out.println("invalid");
	}

}
