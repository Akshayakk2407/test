package com.cg.emp.junit;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.cg.emp.dao.EmployeeDAOImpl;
import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;



class EmployeeDao {

	
	//static EmployeeDAOImpl empdao=null; 
	//@BeforeClass
		//public static void setUp()
		//{
		static EmployeeDAOImpl	empdao=new EmployeeDAOImpl();
		//} 
	@Test
		public void addEmpTest() throws EmployeeException
		{
			assertEquals(1111, empdao.addEmployee(1111,
					new Employee(1111,"aaa",40000.0F,
							LocalDate.now())));
		} 
}
