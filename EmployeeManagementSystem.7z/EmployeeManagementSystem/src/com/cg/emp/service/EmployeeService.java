package com.cg.emp.service;

import java.util.ArrayList;
import java.util.HashMap;


import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;

public interface EmployeeService {
public int addEmployee(Integer id,Employee ee) throws EmployeeException;
public HashMap<Integer,Employee> fetchAllEmp() ;

public Employee getEmpById(int empid);
public ArrayList<Employee> sortEmpByName();
public HashMap<Integer,Employee> deleteEmp(int empid);
public Employee updateEmp(int empid,String newName,float newSal);
public boolean validateEmpName(String name) throws EmployeeException;
public boolean validateid(String eid) throws EmployeeException;

public boolean Validatesal(String sl) throws EmployeeException;

}
