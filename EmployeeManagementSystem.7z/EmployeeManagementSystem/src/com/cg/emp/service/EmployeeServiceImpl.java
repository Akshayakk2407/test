package com.cg.emp.service;

import java.util.ArrayList;
import java.util.HashMap;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.emp.dao.EmployeeDAO;
import com.cg.emp.dao.EmployeeDAOImpl;
import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDAO employeeDAO=new EmployeeDAOImpl();
	

	@Override
	public int addEmployee(Integer id,Employee ee) throws EmployeeException {
		employeeDAO.addEmployee(id,ee);
		return ee.getEmpid();
	}
   @Override
	public HashMap<Integer,Employee> fetchAllEmp(){
		HashMap<Integer,Employee> h=employeeDAO.fetchAllEmp();
		return h;
	}

@Override
	public Employee getEmpById(int empid) {
		Employee e=employeeDAO.getEmpById(empid);
		return e;
	}

	@Override
	public ArrayList<Employee> sortEmpByName() {
		ArrayList<Employee> al=employeeDAO.sortEmpByName();
		return al;
	}

	@Override
	public HashMap<Integer,Employee>deleteEmp(int empid) {
		HashMap<Integer,Employee> i=employeeDAO.deleteEmp(empid);
		return i;
	}

	@Override
	public Employee updateEmp(int empid, String newName, float newSal) {
		Employee e=employeeDAO.updateEmp(empid,newName,newSal);
		return e;
	}

	@Override
	public boolean validateEmpName(String name) throws EmployeeException {
		Pattern pattern=Pattern.compile("^^[A-Z]{1}[a-z]{1,10}");
		Matcher m=pattern.matcher(name);
		if(m.matches()) {
			return true;
		}
		else {
			return false;
		}
	
	}
	public boolean validateid(String id) throws EmployeeException{
		Pattern pattern=Pattern.compile("[0-9]{4}");
		Matcher m=pattern.matcher(id);
		if(m.matches()) {
			return true;
		}
		else {
			return false;
		}
	}
	

	@Override
	public boolean Validatesal(String sl) throws EmployeeException {
		Pattern pattern=Pattern.compile("[0-9]{5}");
		Matcher m=pattern.matcher(sl);
		if(m.matches()) {
			return true;
		}
		else {
			return false;
		}
		
		
	
	}

	

}
