package com.cg.emp.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;


import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;

import com.cg.emp.service.EmployeeService;
import com.cg.emp.service.EmployeeServiceImpl;



public class RunMain {
	static Scanner sc = null;
	static EmployeeService empservice = null;

	public static void main(String[] args) throws EmployeeException  {
		sc=new Scanner(System.in);
		empservice=new EmployeeServiceImpl();
	
		
		int choice=0;
		
			System.out.println("what do u want to do");
			System.out.println("1: Add Emp\t2:Fetch All Emp\n");
			System.out.println("3:Search Emp by id \t4:Delete Emp\n ");
			System.out.println("5: Sort by name\t6:update emp\n");
			System.out.println("7: exit\n");
			System.out.println("enter choice");
			choice=sc.nextInt();
			
			switch(choice) {
			case 1:
				addEmployee();
			break;
			case 2:
				fetchEmp();
			break;
			case 3:
				getEmpById();
				break;
			case 4:
				DeleteEmp();
				break;
		    case 5:
		    	sortEmpByName();
		    	break;
		    case 6:
		    	UpdateEmp();
			break;
		    default:
		    	System.out.println("wrng choice");
			}	
			
		}
		
	
	

	public static void addEmployee() {

		
			System.out.println("enter id: ");
			String eid = sc.next();
			try {
				if (empservice.validateid(eid)==true) {
					
						System.out.println("enter emp name:");
						String name = sc.next();
						try {
							if (empservice.validateEmpName(name)==true) {
								
								System.out.println("enter emp sal:");
								String sl = sc.next();
								
								try {
									if ((empservice.Validatesal(sl))==true) {
								Employee employee=new Employee(Integer.parseInt(eid),name,Float.parseFloat(sl),LocalDate.now());
								System.out.println(employee);
								int empId=empservice.addEmployee(Integer.parseInt(eid),employee);
								System.out.println("employee added "+empId);
							
								}
									else {throw new EmployeeException(sl);}
							}
								catch(EmployeeException e) {
									e.getStackTrace();
								}
							}else {throw new EmployeeException(name);}}
						    catch (EmployeeException e) 
						{
                          e.getStackTrace();
						}
						
					}
					else {throw new EmployeeException(eid);

				}

			} catch (EmployeeException exc) {
				exc.getStackTrace();

			}
		}

private static void fetchEmp()  {
	HashMap<Integer,Employee> hs=empservice.fetchAllEmp();
     
 System.out.println(hs.entrySet());
	                                                    
	    }                                                    
	
private static void getEmpById() {
	System.out.println("enter id: ");
	int eid = sc.nextInt();
	
	Employee e=empservice.getEmpById(eid);
	try {
		if(e!=null) 
	
			System.out.println(e);
		else {
			throw new EmployeeException(null);
		}
	}
		catch(EmployeeException e1) {
			e1.getStackTrace();
		}
			
		}

private static void DeleteEmp() {
	System.out.println("enter id: ");
	int eid = sc.nextInt();
	HashMap<Integer,Employee> t=empservice.fetchAllEmp();
	try {
		if(t.containsKey(eid)) 
		{
			HashMap<Integer,Employee> e=empservice.deleteEmp(eid);
			System.out.println("after deletion of employee"+" " +eid+" "+"remaining employees are: ");
			System.out.println(e);}
		else {
			throw new EmployeeException(null);
		}
	}
		catch(EmployeeException e1) {
			e1.getStackTrace();
		}
			
	
}

public static void sortEmpByName() {
	ArrayList<Employee> ee=empservice.sortEmpByName();
	System.out.println("sorted list by employee name: ");
	Iterator<Employee> i=ee.iterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
}

private static void UpdateEmp() throws EmployeeException {
	System.out.println("enter id");
	int id=sc.nextInt();
	Employee e=empservice.getEmpById(id);
	
	
      System.out.println("enter new name to be updated");
      String newName=sc.next();
      
      System.out.println("enter salary to be updated");
	float newSal=sc.nextFloat();
	e.setEmpname(newName);
	e.setEmpsal(newSal);
	System.out.println(e);
	}


}



	


