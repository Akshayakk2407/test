package com.cg.emp.util;

import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;

import com.cg.emp.entity.Employee;

public class CollectionUtil{
	private static HashMap<Integer,Employee> map=new HashMap<Integer,Employee>();
	static {
		map.put(1001,new Employee(1001,"uday",45000.0F,LocalDate.of(2019,Month.JANUARY,04)));
		map.put(1002,new Employee(1002,"rama",55000.0F,LocalDate.of(2018,Month.JANUARY,04)));
		map.put(1003,new Employee(1003,"uda",35000.0F,LocalDate.of(2019,Month.FEBRUARY,04)));
		map.put(1004,new Employee(1004,"janu",47000.0F,LocalDate.of(2019,Month.JANUARY,04)));
		map.put(1005,new Employee(1005,"balu",48000.0F,LocalDate.of(2019,Month.JANUARY,04)));
	}
	static ArrayList<Employee> al=new ArrayList<Employee>();
	static {
	    al.add(new Employee(1001,"uday",45000.0F,LocalDate.of(2019,Month.JANUARY,04)));
		al.add(new Employee(1002,"rama",55000.0F,LocalDate.of(2018,Month.JANUARY,04)));
		al.add(new Employee(1003,"uda",35000.0F,LocalDate.of(2019,Month.FEBRUARY,04)));
		al.add(new Employee(1004,"janu",47000.0F,LocalDate.of(2019,Month.JANUARY,04)));
		al.add(new Employee(1005,"balu",48000.0F,LocalDate.of(2019,Month.JANUARY,04)));
	}
	public static void addEmployee(Integer id,Employee ee) { 
	map.put(id,ee);
	}
	public static HashMap fetchAllEmp() { //return employee type
		       return map;
		}
	public static Employee getEmpById(int empid) {
	
		return map.get(empid);
		
	}
	public static HashMap<Integer, Employee> deleteEmp(int empid) {
		map.remove(empid);
		return map;
	}
	public static ArrayList<Employee> sortEmpByName() {
		Collection<Employee> c=map.values();
		Collections.sort(al, Employee.getCompByName());
		return al;
	}
	
	public static Employee UpdateEmp(int empid, String newName, float newSal) {
		
		return map.get(empid);
	}
	
	}
	


