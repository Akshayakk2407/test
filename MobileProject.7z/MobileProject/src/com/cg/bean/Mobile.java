package com.cg.bean;

public class Mobile {
	
	private int orderId;
	private int custId;
	private double totalpricewithGST;
	
	public Mobile() {
		super();
	}

	public Mobile(int orderId, int custId, double totalpricewithGST) {
		super();
		this.orderId = orderId;
		this.custId = custId;
		this.totalpricewithGST = totalpricewithGST;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public double getTotalpricewithGST() {
		return totalpricewithGST;
	}

	public void setTotalpricewithGST(double totalpricewithGST) {
		this.totalpricewithGST = totalpricewithGST;
	}

	@Override
	public String toString() {
		return "Mobile [orderId=" + orderId + ", custId=" + custId + ", totalpricewithGST=" + totalpricewithGST + "]";
	}

}
