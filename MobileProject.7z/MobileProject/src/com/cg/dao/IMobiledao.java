package com.cg.dao;

import java.util.Map;

import com.cg.bean.Customer;
import com.cg.bean.Mobile;
import com.cg.exception.PMSException;

public interface IMobiledao {

	void purchaseMobile(Customer c, Mobile m) throws PMSException;

	Map<Integer, Mobile> getPurchaseDetails(int orderId1) throws PMSException;
	
}
