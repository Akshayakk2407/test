package com.cg.dao;

import java.util.Map;
import java.util.Set;

import com.cg.Utility.PMSUtil;
import com.cg.bean.Customer;
import com.cg.bean.Mobile;
import com.cg.exception.PMSException;

public class IMobiledaoImpl implements IMobiledao {
	
	@Override
	public void purchaseMobile(Customer c,Mobile m)
	{
		Map<Integer, Mobile> map=PMSUtil.getMobiledetails();
		map.put(1, m);
		Map<Integer, Customer> map1=PMSUtil.getCustomerdetails();
		map1.put(1, c);
	}

	@Override
	public Map<Integer, Mobile> getPurchaseDetails(int orderId1) throws PMSException {
		
	    Map<Integer, Mobile> mobile=null;
	    
		Set<Integer> set = PMSUtil.getMobiledetails().keySet();
		
		for (int id : set) {
			
			if (id == orderId1) {
				
				mobile = PMSUtil.getMobiledetails();
				
				break;
			}
		}

		if (mobile == null) {
			throw new PMSException("no order present with the given id ");
		}

		return mobile;
	}

	}

