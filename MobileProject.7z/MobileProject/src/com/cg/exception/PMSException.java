package com.cg.exception;

public class PMSException extends Exception {
	
	public PMSException(String s)
	{
		super(s);
	}

}
