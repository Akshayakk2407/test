package com.cg.service;

import java.util.Map;

import com.cg.bean.Customer;
import com.cg.bean.Mobile;
import com.cg.exception.PMSException;

public interface IMobileService {

	void validateName(String custName) throws PMSException;

	void validateAddress(String address) throws PMSException;

	void validateCellNo(String cellno) throws PMSException;

	void validateOrderId(int orderId) throws PMSException;

	void validateCustId(int custId) throws PMSException;

	void validateModel(String mobileModel) throws PMSException;

	void purchaseMobile(Customer c, Mobile m) throws PMSException;

	Map<Integer, Mobile> getPurchaseDetails(int orderId1) throws PMSException;
	
	
	
	

}
