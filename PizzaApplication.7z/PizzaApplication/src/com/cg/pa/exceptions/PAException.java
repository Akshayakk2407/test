package com.cg.pa.exceptions;

public class PAException extends Exception {

	public PAException(String message) {
		super(message);
	}
}
