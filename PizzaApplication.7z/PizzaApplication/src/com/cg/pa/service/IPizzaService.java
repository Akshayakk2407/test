package com.cg.pa.service;

import com.cg.pa.dto.Customer;
import com.cg.pa.dto.PizzaOrder;
import com.cg.pa.exceptions.PAException;

public interface IPizzaService {

	public void validateName(String name) throws PAException;

	public void validateAddress(String address) throws PAException;

	public void validatePhone(String phone) throws PAException;

	public void validatePizza(String pizzaType) throws PAException;

	public int placeOrder(Customer customer, PizzaOrder order) throws PAException;

	public PizzaOrder getorderDetails(int orderId) throws PAException;

	public void validateOrderId(int orderId) throws PAException;
}
