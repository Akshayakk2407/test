package com.cg.pa.service;

import java.util.regex.Pattern;

import com.cg.pa.dao.IPizzaDAO;
import com.cg.pa.dao.PizzaDAOImpl;
import com.cg.pa.dto.Customer;
import com.cg.pa.dto.PizzaOrder;
import com.cg.pa.exceptions.PAException;

public class PizzaServiceImpl implements IPizzaService {

	IPizzaDAO pizzaDao = new PizzaDAOImpl();

	@Override
	public void validateName(String name) throws PAException {

		String nameRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(nameRegEx, name) == false) {
			throw new PAException("name should contain only alphabets");
		}

	}

	@Override
	public void validateAddress(String address) throws PAException {
		String addressRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(addressRegEx, address) == false) {
			throw new PAException("address should contain only alphabets");
		}

	}

	@Override
	public void validatePhone(String phone) throws PAException {
		String phoneRegEx = "[7|8|9]{1}[0-9]{9}";
		if (Pattern.matches(phoneRegEx, phone) == false) {
			throw new PAException("mobile number should contain exactly 10 digits");
		}

	}

	@Override
	public void validatePizza(String pizzaType) throws PAException {
		String pizzaRegEx = "[a-zA-Z]+";
		if (Pattern.matches(pizzaRegEx, pizzaType) == false) {
			throw new PAException("pizza name should contain only alphabets");
		}
	}

	@Override
	public int placeOrder(Customer customer, PizzaOrder order) throws PAException {
		return pizzaDao.placeOrder(customer, order);
	}

	@Override
	public PizzaOrder getorderDetails(int orderId) throws PAException {
		return pizzaDao.getOrderDetails(orderId);
	}

	@Override
	public void validateOrderId(int orderId) throws PAException {

		String idRegEx = "[0-9]+";
		if (Pattern.matches(idRegEx, String.valueOf(orderId)) == false) {
			throw new PAException("orderid should contain only digits");
		}

	}

}
