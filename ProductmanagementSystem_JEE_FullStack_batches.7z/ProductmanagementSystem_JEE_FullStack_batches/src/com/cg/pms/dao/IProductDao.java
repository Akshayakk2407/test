package com.cg.pms.dao;

import java.util.List;

import com.cg.pms.dto.Product;
import com.cg.pms.exceptions.PMSException;

public interface IProductDao {

	int addProduct(Product product) throws PMSException;

	List<Product> getAllProducts() throws PMSException;

	Product searchProduct(int productId) throws PMSException;

}
