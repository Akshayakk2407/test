package com.cg.pms.service;

import java.util.List;

import com.cg.pms.dto.Product;
import com.cg.pms.exceptions.PMSException;

public interface IproductService {

	int addProduct(Product product) throws PMSException;

	public void validateId(int id) throws PMSException;

	public void validateName(String name) throws PMSException;

	public void validateCost(double cost) throws PMSException;

	List<Product> getAllProducts() throws PMSException;

	Product searchProduct(int productId) throws PMSException;

}
